# Package com.facebook.internal

This package is solely for the use of other packages within the Facebook Android SDK, use of any of the classes in this package is unsupported, and they may be modified or removed without warning at any time.

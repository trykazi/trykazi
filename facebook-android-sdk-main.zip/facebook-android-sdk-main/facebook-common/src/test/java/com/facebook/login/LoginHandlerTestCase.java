/*
 * Copyright (c) 2014-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to use,
 * copy, modify, and distribute this software in source code or binary form for use
 * in connection with the web services and APIs provided by Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use of
 * this software is subject to the Facebook Developer Principles and Policies
 * [http://developers.facebook.com/policy/]. This copyright notice shall be
 * included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package com.facebook.login;

import static org.junit.Assert.assertTrue;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

import androidx.fragment.app.FragmentActivity;
import com.facebook.FacebookPowerMockTestCase;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import org.junit.Before;
import org.robolectric.Robolectric;

public abstract class LoginHandlerTestCase extends FacebookPowerMockTestCase {
  protected static final String ACCESS_TOKEN = "An access token";
  protected static final String USER_ID = "123";
  protected static final long EXPIRES_IN_DELTA = 3600 * 24 * 60;
  protected static final HashSet<String> PERMISSIONS =
      new HashSet<String>(Arrays.asList("go outside", "come back in"));
  protected static final String ERROR_MESSAGE = "This is bad!";
  protected static final String CODE_VERIFIER = "codeVerifier";
  protected static final String CODE_CHALLENGE = "codeChallenge";

  protected FragmentActivity activity;
  protected LoginClient mockLoginClient;

  @Before
  public void before() throws Exception {
    mockLoginClient = mock(LoginClient.class);
    activity = Robolectric.buildActivity(FragmentActivity.class).create().get();
    when(mockLoginClient.getActivity()).thenReturn(activity);
  }

  protected LoginClient.Request createRequest() {
    return createRequest(null);
  }

  protected LoginClient.Request createRequest(String previousAccessTokenString) {

    return new LoginClient.Request(
        LoginBehavior.NATIVE_WITH_FALLBACK,
        new HashSet<String>(PERMISSIONS),
        DefaultAudience.FRIENDS,
        "rerequest",
        "1234",
        "5678",
        LoginTargetApp.FACEBOOK,
        AuthenticationTokenTestUtil.NONCE,
        CODE_VERIFIER,
        CODE_CHALLENGE,
        CodeChallengeMethod.S256);
  }

  protected LoginClient.Request createIGAppRequest() {
    return new LoginClient.Request(
        LoginBehavior.NATIVE_WITH_FALLBACK,
        new HashSet<String>(PERMISSIONS),
        DefaultAudience.FRIENDS,
        "rerequest",
        "1234",
        "5678",
        LoginTargetApp.INSTAGRAM);
  }

  protected LoginClient.Request createIGWebRequest() {
    return new LoginClient.Request(
        LoginBehavior.WEB_ONLY,
        new HashSet<String>(PERMISSIONS),
        DefaultAudience.FRIENDS,
        "rerequest",
        "1234",
        "5678",
        LoginTargetApp.INSTAGRAM);
  }

  protected LoginClient.Request createRequestWithNonce() {
    String codeVerifier = PKCEUtil.generateCodeVerifier();
    return new LoginClient.Request(
        LoginBehavior.NATIVE_WITH_FALLBACK,
        new HashSet<String>(PERMISSIONS),
        DefaultAudience.FRIENDS,
        "rerequest",
        "1234",
        "5678",
        null,
        AuthenticationTokenTestUtil.NONCE,
        codeVerifier,
        PKCEUtil.generateCodeChallenge(codeVerifier, CodeChallengeMethod.S256),
        CodeChallengeMethod.S256);
  }

  protected void assertDateDiffersWithinDelta(
      Date expected, Date actual, long expectedDifference, long deltaInMsec) {

    long delta = Math.abs(expected.getTime() - actual.getTime()) - expectedDifference;
    assertTrue(delta < deltaInMsec);
  }

  protected String getEncodedAuthTokenString() {
    return AuthenticationTokenTestUtil.getEncodedAuthTokenStringForTest();
  }
}
